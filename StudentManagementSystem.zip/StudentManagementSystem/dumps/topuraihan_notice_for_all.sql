-- MySQL dump 10.13  Distrib 8.0.25, for Linux (x86_64)
--
-- Host: localhost    Database: topuraihan
-- ------------------------------------------------------
-- Server version	8.0.25-0ubuntu0.20.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `notice_for_all`
--

DROP TABLE IF EXISTS `notice_for_all`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `notice_for_all` (
  `id` int NOT NULL AUTO_INCREMENT,
  `batch` varchar(45) DEFAULT NULL,
  `code` varchar(45) DEFAULT NULL,
  `subject` varchar(45) DEFAULT NULL,
  `creator` varchar(45) DEFAULT NULL,
  `notice` longtext,
  PRIMARY KEY (`id`),
  UNIQUE KEY `code_UNIQUE` (`code`)
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `notice_for_all`
--

LOCK TABLES `notice_for_all` WRITE;
/*!40000 ALTER TABLE `notice_for_all` DISABLE KEYS */;
INSERT INTO `notice_for_all` VALUES (1,'27th','topu','vacation','','Rusty Griswold plans a cross-country road trip with his wife and two sons in a bid to revive the lost ties between them. However, their trip turns into a series of mishaps for the family.\nRusty Griswold is now an adult working as a pilot for a low budget regional airline called Econo-Air, living in Suburban Chicago and shares a stale relationship with his wife Debbie and their two children, their shy and awkward 14-year-old son James, and their sadistic 12-year-old son Kevin. The gloating from his friends Jack and Nancy Peterson about a family trip they had in Paris doesn\'t help his situation.\n\nHe desires to relive the fun of his family vacations and holiday gatherings from his childhood. These memories prompt him to abandon his family\'s annual trip to their cabin in Cheboygan, Michigan (which the rest of the family secretly hated) and instead drive cross country from Chicago to Walley World, just like he did with his parents and sister. For the trip, Rusty rents a Tartan Prancer, an ugly, over-complicated Albanian SUV.\n\nAlong the way, the Griswolds take many detours. The first is Memphis, where it\'s revealed that the otherwise mild-mannered Debbie was an extremely promiscuous Tri Pi sorority sister in college nicknamed \'Debbie Do Anything\' when they meet a sorority member named Heather. To prove that she was the rebellious student, Debbie soon runs an obstacle course whilst drunk and fails miserably. While staying at a motel, James meets Adena, a girl his age that he saw while driving on the highway, but she is scared away by Rusty\'s failed attempts to be a \"wingman\".\n\nIn Arkansas, they are led to a supposedly hidden hot spring by a \"helpful\" local, eventually realizing that it\'s actually a raw sewage dump. They return to their SUV, only to see it\'s been broken into, their luggage and cash stolen, and then sprayed with graffiti.'),(5,'29th','raihan','info','','alert.setAlertType(AlertType.ERROR);\n				alert.setHeaderText(\"FAILED......\");\n				alert.setHeaderText(\"there are some problems to add new notice into system\\nplease try again or check for faults\");\n				alert.showAndWait();\nalert.setAlertType(AlertType.ERROR);\n				alert.setHeaderText(\"FAILED......\");\n				alert.setHeaderText(\"there are some problems to add new notice into system\\nplease '),(9,'27th','schedule','schedule','','	Start			End			Course\n	------------------------------------------------------\n	09.00AM 		10.00AM 		Bangla\n	11.00AM 		12.00AM 		English\n	02.00PM 		03.00PM 		Math\n	04.00PM 		05.00PM 		Science'),(12,'28th','schedule1','schedule','topu','	Start			End			Course\n	------------------------------------------------------\n	09.00AM 		10.00AM 		Math\n	11.00AM 		12.00AM 		Science\n	02.00PM 		03.00PM 		Bangla\n	04.00PM 		05.00PM 		English'),(16,'27th','assignment','newAssignment',NULL,'All student are instructed to do the following assignment with in 3 days\n\n\nwrite 5 essays\nwrite 5 paragraph\nwrite 1 comprehension\n\n\nthanks');
/*!40000 ALTER TABLE `notice_for_all` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2021-06-02 17:39:58
