-- MySQL dump 10.13  Distrib 8.0.25, for Linux (x86_64)
--
-- Host: localhost    Database: topuraihan
-- ------------------------------------------------------
-- Server version	8.0.25-0ubuntu0.20.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `attendence`
--

DROP TABLE IF EXISTS `attendence`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `attendence` (
  `id` int NOT NULL AUTO_INCREMENT,
  `registration` int DEFAULT NULL,
  `name` varchar(45) DEFAULT NULL,
  `attendence` tinyint DEFAULT NULL,
  `time_date` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=196 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `attendence`
--

LOCK TABLES `attendence` WRITE;
/*!40000 ALTER TABLE `attendence` DISABLE KEYS */;
INSERT INTO `attendence` VALUES (63,10,'Jakir Hossain',1,'2021-03-28 11:31:36'),(64,11,'Master the boss',1,'2021-03-28 11:31:36'),(65,12,'Kanon Khan',0,'2021-03-28 11:31:36'),(66,13,'Sobuj Rahman',1,'2021-03-28 11:31:36'),(67,14,'Tushar Ahmed',1,'2021-03-28 11:31:36'),(68,15,'Tshin Rono',1,'2021-03-28 11:31:36'),(69,16,'Tamim Ahmed',0,'2021-03-28 11:31:36'),(70,17,'Tuhin Shahnawas',1,'2021-03-28 11:31:36'),(71,2014014342,'Raihan Khan',1,'2021-03-28 11:31:36'),(72,8,'bashir hossain',1,'2021-03-28 11:31:37'),(73,9,'Amjad Hosain',0,'2021-03-28 11:31:37'),(74,10,'Jakir Hossain',0,'2021-03-29 19:10:28'),(75,11,'Master the boss',1,'2021-03-29 19:10:28'),(76,12,'Kanon Khan',1,'2021-03-29 19:10:28'),(77,13,'Sobuj Rahman',0,'2021-03-29 19:10:28'),(78,14,'Tushar Ahmed',1,'2021-03-29 19:10:28'),(79,15,'Tshin Rono',1,'2021-03-29 19:10:28'),(80,16,'Tamim Ahmed',1,'2021-03-29 19:10:28'),(81,17,'Tuhin Shahnawas',0,'2021-03-29 19:10:28'),(82,2014014342,'Raihan Khan',1,'2021-03-29 19:10:28'),(83,8,'bashir hossain',1,'2021-03-29 19:10:28'),(84,9,'Amjad Hosain',0,'2021-03-29 19:10:28'),(85,10,'Jakir Hossain',1,'2021-03-31 23:34:46'),(86,11,'Master the boss',1,'2021-03-31 23:34:46'),(87,12,'Kanon Khan',1,'2021-03-31 23:34:46'),(88,13,'Sobuj Rahman',1,'2021-03-31 23:34:46'),(89,14,'Tushar Ahmed',1,'2021-03-31 23:34:46'),(90,15,'Tshin Rono',0,'2021-03-31 23:34:46'),(91,16,'Tamim Ahmed',1,'2021-03-31 23:34:46'),(92,17,'Tuhin Shahnawas',1,'2021-03-31 23:34:46'),(93,2014014342,'Raihan Khan',1,'2021-03-31 23:34:46'),(94,8,'bashir hossain',0,'2021-03-31 23:34:46'),(95,9,'Amjad Hosain',0,'2021-03-31 23:34:46'),(96,2014014320,'Md. Topu Raihan',1,'2021-03-27 23:03:56'),(97,2014014320,'Md. Topu Raihan',0,'2021-03-28 23:04:01'),(98,2014014320,'Md. Topu Raihan',1,'2021-03-29 23:04:04'),(99,2014014320,'Md. Topu Raihan',0,'2021-03-30 23:04:06'),(100,2014014320,'Md. Topu Raihan',1,'2021-03-31 23:04:10'),(101,2014014320,'Md. Topu Raihan',0,'2021-04-01 23:04:12'),(102,2014014320,'Md. Topu Raihan',1,'2021-04-02 23:04:14'),(103,2014014320,'Md. Topu Raihan',1,'2021-04-03 23:04:17'),(104,2014014320,'Md. Topu Raihan',1,'2021-04-04 23:04:20'),(105,2014014320,'Md. Topu Raihan',0,'2021-04-05 23:04:22'),(106,18,'Sulaiman Hossain',1,'2021-04-06 00:19:32'),(107,3,'mtr',0,'2021-04-07 00:19:32'),(161,2014014318,'Sulaiman Hossain',1,'2021-04-14 12:42:33'),(162,2014014308,'bashir hossain',1,'2021-04-17 22:07:29'),(163,2014014309,'Amzad Hosain',1,'2021-04-17 22:07:29'),(164,2014014315,'Tshin Rono',1,'2021-04-17 22:07:29'),(165,2014014316,'Tamim Ahmed',0,'2021-04-17 22:07:29'),(166,2014014317,'Tuhin Shahnawas',0,'2021-04-17 22:07:29'),(167,2014014320,'Md. Topu Raihan',1,'2021-04-17 22:07:29'),(168,2014014341,'topu fdsf',1,'2021-04-17 22:07:29'),(169,2014014342,'Raihan Khan',1,'2021-04-17 22:07:29'),(170,2014014318,'Sulaiman Hossain',1,'2021-04-17 22:15:51'),(171,2014014318,'Sulaiman Hossain',1,'2021-04-26 14:18:57'),(172,2014014308,'bashir hossain',1,'2021-05-18 11:34:33'),(173,2014014309,'Amzad Hosain',0,'2021-05-18 11:34:33'),(174,2014014315,'Tshin Rono',0,'2021-05-18 11:34:33'),(175,2014014316,'Tamim Ahmed',1,'2021-05-18 11:34:33'),(176,2014014317,'Tuhin Shahnawas',1,'2021-05-18 11:34:33'),(177,2014014320,'Md. Topu Raihan',0,'2021-05-18 11:34:33'),(178,2014014341,'topu fdsf',1,'2021-05-18 11:34:33'),(179,2014014342,'Raihan Khan',1,'2021-05-18 11:34:33'),(180,2014014308,'bashir hossain',1,'2021-05-24 14:20:57'),(181,2014014309,'Amzad Hosain',1,'2021-05-24 14:20:57'),(182,2014014315,'Tshin Rono',1,'2021-05-24 14:20:57'),(183,2014014316,'Tamim Ahmed',0,'2021-05-24 14:20:57'),(184,2014014317,'Tuhin Shahnawas',1,'2021-05-24 14:20:57'),(185,2014014320,'Md. Topu Raihan',0,'2021-05-24 14:20:57'),(186,2014014341,'topu fdsf',1,'2021-05-24 14:20:57'),(187,2014014342,'Raihan Khan',0,'2021-05-24 14:20:57'),(188,2014014308,'bashir hossain',1,'2021-05-29 17:49:01'),(189,2014014309,'Amzad Hosain',1,'2021-05-29 17:49:01'),(190,2014014315,'Tshin Rono',1,'2021-05-29 17:49:01'),(191,2014014316,'Tamim Ahmed',0,'2021-05-29 17:49:01'),(192,2014014317,'Tuhin Shahnawas',1,'2021-05-29 17:49:01'),(193,2014014320,'Md. Topu Raihan',1,'2021-05-29 17:49:01'),(194,2014014341,'topu fdsf',0,'2021-05-29 17:49:01'),(195,2014014342,'Raihan Khan',0,'2021-05-29 17:49:01');
/*!40000 ALTER TABLE `attendence` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2021-06-02 17:39:57
